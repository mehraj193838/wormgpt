# WormGPT

### About Tool
<div align="center">
  <img src="https://i.imgur.com/DJEZGdY.jpg" alt="Index" width="200" height="400"> 
</div>

The WormGPT tool is a tool that helps you create unethical tools in any programming language and helps you do anything unethical. You are not responsible for any incorrect use of the tool. 

#

#### Tested On  :

* Kali Linux

* BlackArch Linux

* Kali Nethunter

* Termux ( Rooted/NonRooted Devices)


### Installation

```
pkg update && pkg upgrade -y
```
```
pkg install git -y
```
```
pkg install python3
```
```
git clone https://github.com/black-demon-dr7/WormGPT.git
```
```
cd WormGPT
```
```
pip install -r requirements.txt
```
```
chmod +x *
```
```
python3 WormGPT.py
```



## [~] Contact Me on :

- [![Github](https://img.shields.io/badge/Github-Demon-purple?style=for-the-badge&logo=github)](https://github.com/black-demon-dr7)

- [![Instgram](https://img.shields.io/badge/Instagram-Demon-green?style=for-the-badge&logo=instagram)](https://instagram.com/elqnas_daymon?igshid=MzNlNGNkZWQ4Mg==)

- [![Youtube](https://img.shields.io/badge/Youtube-Demon-blue?style=for-the-badge&logo=youtube)](https://youtube.com/@ELQNAS_DAYMON?si=_9glDyUgFdJ1JDsW)

- [![Telegram](https://img.shields.io/badge/Telegram-Demon-orange?style=for-the-badge&logo=telegram)](https://t.me/BLACK_DEMON_VX)

- [![Connect](https://img.shields.io/badge/Telegram-Demon-indigo?style=for-the-badge&logo=telegram)](https://t.me/blackd4)
#
#### Tools Languages :

![Customized Card](https://github-readme-stats.vercel.app/api/pin?username=black-demon-dr7&repo=WormGPT&title_color=fff&icon_color=f9f9f9&text_color=9f9f9f&bg_color=151515)
#
### ©️ Copyright
Copyright © 2023 by [Black Demon](https://github.com/black-demon-dr7)
